# AM Trade SDK - Master Documentation

**Status:** Ready for Production  
**Last Updated:** December 5, 2025

> **Note:** This is the master SDK documentation. This file should be referenced in both `am-trade-sdk-core/` and `am-trade-sdk-python/` folders.

---

## 📋 Overview

The AM Trade SDK provides language-specific libraries to integrate with the AM Trade Management system:

| Aspect | Java SDK | Python SDK |
|--------|----------|-----------|
| **Location** | `am-trade-sdk-core/` | `am-trade-sdk-python/` |
| **Name** | am-trade-sdk-core | am-trade-sdk-python |
| **Artifact** | JAR | Package (PyPI) |
| **Language** | Java 17+ | Python 3.8+ |
| **Package Manager** | Maven | pip |
| **HTTP Client** | OkHttp | requests |
| **Serialization** | Gson | pydantic |

---

## 🚀 Quick Start

### Java SDK

```xml
<dependency>
    <groupId>am.trade</groupId>
    <artifactId>am-trade-sdk-core</artifactId>
    <version>1.0.0</version>
</dependency>
```

```java
// Initialize SDK
AmTradeSdk sdk = new AmTradeSdk(
    "http://localhost:8073",
    "your-api-key"
);

// Get trades
List<Trade> trades = sdk.getTradeClient().getAllTrades();

// Filter trades by FREE tier
Map<String, Object> freeTrades = sdk.getTradeClient()
    .getTradesByFreeTab(0, 20);
```

### Python SDK

```bash
pip install am-trade-sdk
```

```python
from am_trade_sdk import AmTradeSdk

# Initialize SDK
sdk = AmTradeSdk(
    api_url="http://localhost:8073",
    api_key="your-api-key"
)

# Get trades
trades = sdk.trade_client.get_all_trades()

# Filter trades by FREE tier
free_trades = sdk.trade_client.get_trades_by_free_tab(page=0, page_size=20)
```

---

## 📚 Core Features

### Trade Management

**Get all trades:**
```java
// Java
List<Trade> trades = sdk.getTradeClient().getAllTrades(0, 20);
```

```python
# Python
trades = sdk.trade_client.get_all_trades(page=0, page_size=20)
```

**Get specific trade:**
```java
// Java
Trade trade = sdk.getTradeClient().getTradeById("trade-123");
```

```python
# Python
trade = sdk.trade_client.get_trade_by_id("trade-123")
```

**Create trade:**
```java
// Java
Trade newTrade = sdk.getTradeClient().createTrade(
    "portfolio-123",
    "NIFTY",
    "FUTURES",
    10,
    18500.00,
    "2025-01-15"
);
```

```python
# Python
new_trade = sdk.trade_client.create_trade(
    portfolio_id="portfolio-123",
    symbol="NIFTY",
    trade_type="FUTURES",
    quantity=10,
    entry_price=18500.00,
    entry_date="2025-01-15"
)
```

### Free Tab Feature (NEW)

**Get trades available in FREE tier:**
```java
// Java - Get FREE tier trades (max 20 per page)
Map<String, Object> freeTrades = sdk.getTradeClient()
    .getTradesByFreeTab(0, 20);

// With symbol filter
Map<String, Object> niftyTrades = sdk.getTradeClient()
    .getTradesByFreeTabAndSymbol("NIFTY", 0, 20);

// With status filter
Map<String, Object> winningTrades = sdk.getTradeClient()
    .getTradesByFreeTabAndStatus("WIN", 0, 20);
```

```python
# Python - Get FREE tier trades (max 20 per page)
free_trades = sdk.trade_client.get_trades_by_free_tab(page=0, page_size=20)

# With symbol filter
nifty_trades = sdk.trade_client.get_trades_by_free_tab_and_symbol(
    symbol="NIFTY", 
    page=0, 
    page_size=20
)

# With status filter
winning_trades = sdk.trade_client.get_trades_by_free_tab_and_status(
    status="WIN",
    page=0,
    page_size=20
)
```

**FREE Tier Fields:**
- ✅ id
- ✅ portfolio_id
- ✅ symbol
- ✅ trade_type
- ✅ quantity
- ✅ entry_price
- ✅ entry_date
- ✅ status
- ✅ pnl
- ✅ pnl_percentage

### Portfolio Operations

**Get portfolio:**
```java
// Java
Portfolio portfolio = sdk.getPortfolioClient()
    .getPortfolioById("portfolio-123");
```

```python
# Python
portfolio = sdk.portfolio_client.get_portfolio_by_id("portfolio-123")
```

**Get portfolio trades:**
```java
// Java
List<Trade> trades = sdk.getTradeClient()
    .getTradesByPortfolio("portfolio-123", 0, 20);
```

```python
# Python
trades = sdk.trade_client.get_trades_by_portfolio(
    portfolio_id="portfolio-123",
    page=0,
    page_size=20
)
```

### Journal Management

**Create journal entry:**
```java
// Java
Journal entry = sdk.getJournalClient()
    .createJournal("trade-123", "Great win today!", "Technical setup");
```

```python
# Python
entry = sdk.journal_client.create_journal(
    trade_id="trade-123",
    title="Great win today!",
    notes="Technical setup"
)
```

### Filter Management

**Create favorite filter:**
```java
// Java
FavoriteFilter filter = sdk.getFilterClient()
    .createFilter("My Winning Trades", filterConfig, true);
```

```python
# Python
filter = sdk.filter_client.create_filter(
    name="My Winning Trades",
    filter_config=filter_config,
    is_default=True
)
```

**Apply favorite filter:**
```java
// Java
List<Trade> filteredTrades = sdk.getTradeClient()
    .filterTrades(filterCriteria);
```

```python
# Python
filtered_trades = sdk.trade_client.filter_trades(
    portfolio_id="portfolio-123",
    statuses=["WIN"],
    min_pnl=1000.0
)
```

---

## 🔐 Tier-Based Access Control

The SDK automatically handles tier-based field filtering:

**FREE Tier:**
- 10 fields visible
- 10 requests/minute
- Max batch size: 10
- Max page size: 20

**PREMIUM Tier:**
- 13 fields visible (+ transaction_cost, fee_paid, tax_impact)
- 100 requests/minute
- Max batch size: 100
- Max page size: 500

**ENTERPRISE Tier:**
- 16 fields visible (+ margin_used, internal_id, metadata)
- 1000 requests/minute
- Max batch size: 1000
- Max page size: 5000

```java
// Java - Check user tier
UserTier tier = sdk.getTradeClient().getTierContext().getUserTier();
System.out.println("User tier: " + tier);

// Check if feature available
boolean canBatch = sdk.getTradeClient().getTierContext()
    .isFeatureAvailable("batch_operations");
```

```python
# Python - Check user tier
tier = sdk.trade_client.tier_context.user_tier
print(f"User tier: {tier.value}")

# Check if feature available
can_batch = sdk.trade_client.tier_context.is_feature_available("batch_operations")
```

---

## 🛠️ Advanced Usage

### Batch Operations

```java
// Java - Batch create trades
List<Trade> trades = Arrays.asList(
    new Trade("NIFTY", 10, 18500.00),
    new Trade("BANKNIFTY", 5, 45000.00)
);
List<Trade> created = sdk.getTradeClient().batchCreateTrades(trades);
```

```python
# Python - Batch create trades
trades = [
    {"symbol": "NIFTY", "quantity": 10, "entry_price": 18500.00},
    {"symbol": "BANKNIFTY", "quantity": 5, "entry_price": 45000.00}
]
created = sdk.trade_client.batch_create_trades(trades)
```

### Error Handling

```java
// Java
try {
    Trade trade = sdk.getTradeClient().getTradeById("invalid-id");
} catch (ResourceNotFoundException e) {
    System.err.println("Trade not found: " + e.getMessage());
} catch (ApiException e) {
    System.err.println("API error: " + e.getMessage());
}
```

```python
# Python
try:
    trade = sdk.trade_client.get_trade_by_id("invalid-id")
except sdk.exceptions.ResourceNotFoundException:
    print("Trade not found")
except sdk.exceptions.ApiException as e:
    print(f"API error: {e}")
```

### Pagination

```java
// Java
Page<Trade> page = sdk.getTradeClient()
    .getAllTrades(2, 50);  // Get page 2 with 50 items
System.out.println("Total: " + page.getTotalCount());
System.out.println("Pages: " + page.getTotalPages());
```

```python
# Python
response = sdk.trade_client.get_all_trades(page=2, page_size=50)
print(f"Total: {response['totalCount']}")
print(f"Pages: {response['totalPages']}")
```

---

## 📦 Project Structure

### Java SDK (`am-trade-sdk-core/`)

```
am-trade-sdk-core/
├── pom.xml
└── src/main/java/am/trade/sdk/
    ├── AmTradeSdk.java          # Main SDK entry point
    ├── client/
    │   ├── BaseApiClient.java
    │   ├── TradeApiClient.java
    │   ├── PortfolioClient.java
    │   ├── JournalClient.java
    │   └── FilterClient.java
    ├── config/
    │   └── SdkConfiguration.java
    ├── dto/                      # Data Transfer Objects
    ├── exceptions/               # Custom exceptions
    └── util/                     # Utilities
```

### Python SDK (`am-trade-sdk-python/`)

```
am-trade-sdk-python/
├── pyproject.toml
├── setup.py
└── am_trade_sdk/
    ├── __init__.py              # Main SDK entry point
    ├── client.py                # AmTradeSdk class
    ├── base_client.py
    ├── trade_client.py
    ├── portfolio_client.py
    ├── journal_client.py
    ├── filter_client.py
    ├── config.py                # Configuration
    ├── dto.py                   # DTOs
    ├── exceptions.py            # Custom exceptions
    └── tier.py                  # Tier-based access control
```

---

## 🧪 Testing

### Java SDK

```java
@Test
public void testGetTradeByFreeTab() {
    Map<String, Object> freeTrades = sdk.getTradeClient()
        .getTradesByFreeTab(0, 20);
    
    assertNotNull(freeTrades);
    assertTrue(freeTrades.containsKey("trades"));
    assertTrue(freeTrades.containsKey("totalCount"));
}

@Test
public void testGetTradeByFreeTabWithSymbol() {
    Map<String, Object> trades = sdk.getTradeClient()
        .getTradesByFreeTabAndSymbol("NIFTY", 0, 20);
    
    assertNotNull(trades);
    assertEquals("NIFTY", trades.get("symbol"));
}
```

### Python SDK

```python
def test_get_trades_by_free_tab():
    free_trades = sdk.trade_client.get_trades_by_free_tab(page=0, page_size=20)
    
    assert free_trades is not None
    assert "trades" in free_trades
    assert "totalCount" in free_trades

def test_get_trades_by_free_tab_with_symbol():
    trades = sdk.trade_client.get_trades_by_free_tab_and_symbol(
        symbol="NIFTY",
        page=0,
        page_size=20
    )
    
    assert trades is not None
    assert trades["symbol"] == "NIFTY"
```

---

## 🔗 Configuration

### Java SDK

```java
// Configuration builder
SdkConfiguration config = SdkConfiguration.builder()
    .apiUrl("http://localhost:8073")
    .apiKey("your-api-key")
    .timeout(30)
    .retryAttempts(3)
    .build();

AmTradeSdk sdk = new AmTradeSdk(config);
```

### Python SDK

```python
from am_trade_sdk import SdkConfig, ConfigBuilder

# Configuration builder
config = ConfigBuilder() \
    .api_url("http://localhost:8073") \
    .api_key("your-api-key") \
    .timeout(30) \
    .retry_attempts(3) \
    .build()

sdk = AmTradeSdk(config=config)
```

---

## 📊 API Response Format

All FREE tab endpoints return:

```json
{
  "trades": [
    {
      "id": "trade-123",
      "portfolio_id": "portfolio-456",
      "symbol": "NIFTY",
      "trade_type": "FUTURES",
      "quantity": 10,
      "entry_price": 18500.00,
      "entry_date": "2025-01-15",
      "status": "WIN",
      "pnl": 5000.00,
      "pnl_percentage": 2.50
    }
  ],
  "totalCount": 150,
  "page": 0,
  "size": 20,
  "totalPages": 8,
  "isFirst": true,
  "isLast": false
}
```

---

## ⚠️ Important Notes

1. **FREE Tier Limits:**
   - Max page size: 20 (automatically enforced)
   - Max batch operations: 10 items
   - Rate limited to 10 requests/minute

2. **Field Filtering:**
   - FREE tier users automatically receive filtered responses
   - Extra fields are removed from responses
   - No code changes needed for tier upgrades

3. **Error Handling:**
   - Always catch `ApiException` and tier-specific exceptions
   - Use specific exception types for granular error handling
   - Log errors for debugging

4. **Performance:**
   - Use pagination for large datasets
   - Batch operations for creating multiple trades
   - Cache token and tier information

---

## 🔄 Upgrade from FREE to PREMIUM

When a user upgrades their tier:

1. New JWT token is generated with `tier: "PREMIUM"`
2. SDK automatically detects new tier
3. Same code works with more fields visible
4. No client code changes required

```java
// Same code works for all tiers!
Trade trade = sdk.getTradeClient().getTradeById("trade-123");
// FREE: receives 10 fields
// PREMIUM: receives 13 fields (automatic!)
// ENTERPRISE: receives 16 fields (automatic!)
```

---

## 📞 Support

For issues or questions:
- Check the [TIER-BASED-ACCESS-CONTROL.md](../TIER-BASED-ACCESS-CONTROL.md) for tier details
- Review [TIER-QUICK-REFERENCE.md](../TIER-QUICK-REFERENCE.md) for quick answers
- Consult [SDK-STRATEGY-PLAN.md](../SDK-STRATEGY-PLAN.md) for architecture details

---

## 📄 License

Part of AM Trade Management System - All rights reserved

---

**Last Updated:** December 5, 2025  
**Version:** 1.0.0  
**Status:** Production Ready
